Tang Biographies


Source:  Chinese Historical Studies [CHS]
(c) 1985 Robert M. Hartwell
(c) 2005  Harvard Yenching Institute


Description:  The 1,878 records in this file were extracted from the 30,000 biographical records database, CHS.  These represent all the Tang Dynasty records found in the database.   The locations are based on centroid points calculated from historical Chinese GIS data also produced by Robert Hartwell.   The locations are NOT part of the CHGIS data, but are expected to be cross-referenced in the future.

Editor:  Lex Berman